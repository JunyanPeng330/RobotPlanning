using UnityEngine;
using System.Collections;

public class HingeJointLengthCalculation : MonoBehaviour {

    public HingeJoint hingeJoint;
    
    void Start () 
    {
        if (hingeJoint != null)
        {
            ComputeLinkLength();
        }
        else
        {
            Debug.LogError("Hinge joint reference is not set!");
        } 
	}
	
	void ComputeLinkLength() 
    {
        Vector3 anchorPosition = hingeJoint.anchor;
        Vector3 connectedAnchorPosition = hingeJoint.connectedAnchor;
        Debug.Log("anchor position:" + anchorPosition);
        Debug.Log("connected anchor position:" + connectedAnchorPosition);
        float linkLength = Vector3.Distance(anchorPosition, connectedAnchorPosition);
        Debug.Log("Link Length: " + linkLength);
	}

}
